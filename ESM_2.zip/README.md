# Online Resource 2: reproducibility archive

Article: *Heterogeneity-calibrated Byzantine-robust distributed composite
quantile regression*

Authors: Xiaofei Wu; Jian Qing Shi

Corresponding author: Jian Qing Shi  
Corresponding affiliation: Department of Statistics and Data Science, Beijing
Normal--Hong Kong Baptist University, Zhuhai, China  
Corresponding e-mail: jianqingshi@bnbu.edu.cn

## Contents

- **code/hcrcqr.py**: estimator, attacks, baselines, and evaluation functions.
- **code/run_simulation.py**: all six reported Monte Carlo settings.
- **code/run_bikesharing.py**: the temporally split UCI Bike Sharing analysis.
- **code/make_artifacts.py**: regeneration of table fragments and figure data.
- **code/test_hcrcqr.py**: deterministic implementation checks.
- **code/run_matched.py**: added paired calibration comparison (50 replications
  per setting); changes only the preconditioner, using common initialization,
  four rounds, thresholds, attack seeds and norm caps.
- **results/**: replicate-level and summarized results used in the manuscript.
- **figures/**: values used to draw the simulation error and support-recovery plots and the Bike Sharing performance plot.
- **data/README.md**: public-data retrieval and integrity instructions.

## Software environment

The archived results were generated with:

- Python 3.12.14
- NumPy 2.3.5
- pandas 3.0.1

Install the recorded dependencies with:

    python -m pip install -r requirements.txt

## Reproduce the checks and simulations

Run these commands from the **code** directory:

    python -m unittest -v test_hcrcqr.py
    python run_simulation.py --reps 50 --output ../results
    python run_bikesharing.py --data ../data/hour.csv --reps 10 --output ../results
    python make_artifacts.py
    python run_matched.py --reps 50 --workers 4

The Monte Carlo driver uses 50 independent seeds for each of six settings.
The Bike Sharing driver uses ten independently seeded Byzantine-site
assignments for each attacked setting. Seeds and all method-level outcomes are
stored in the replicate files.

The no-attack Bike Sharing analysis is deterministic, so reported Monte Carlo
standard errors round to zero.

## Data and redistribution

The UCI source data are not redistributed in this archive. Download
**Bike-Sharing-Dataset.zip** from the permanent repository record
<https://doi.org/10.24432/C5W894>, extract **hour.csv**, and place it at
**data/hour.csv**. See **data/README.md** for the source citation and validation
checks.

## Scope

The supplied implementation uses a ridge inverse profile Hessian, matching the
reported moderate-dimensional experiments. The manuscript also describes a
Dantzig/CLIME-type option for high-dimensional inverse-Hessian calibration;
that optional solver is not used in, and is not needed to reproduce, the
reported tables.

The Bike Sharing penalty uses the median size of sites known to be honest in
each controlled assignment. This is an oracle benchmarking convenience, not a
deployment-ready tuning rule. Continuous-feature standardization is computed
from pooled training data and treated as trusted preprocessing; attacks affect
only model messages. The Newton implementation also caps large steps for
numerical stability, whereas the stated theory concerns uncapped messages.
The original method comparisons use their archived method-specific initializations
and iteration budgets. The added matched comparison is reported separately in
`matched_replicates.csv` and `matched_summary.csv`. It compares a local ridge
inverse with scalar preconditioners 1, 4 and 8, without post-hoc step selection.
Round-level records include honest-message dispersion and cap counts. Paired
differences are scalar error minus local-inverse error. Scalar step 4 has
slightly lower mean error under heterogeneous sign reversal; all results are
retained. The experiment does not establish superiority over every tuned step.

The numerical records correspond to the supplied ridge implementation and
its documented tuning. The conditional theorem does not certify these
experimental choices.

The sign-reversal and mimic attacks are constructed from the realized honest
messages at each attack step. They are therefore omniscient stress tests; the
archive does not evaluate attacks restricted to a malicious worker's own data
or past broadcasts.
