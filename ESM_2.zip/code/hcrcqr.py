"""Core routines for heterogeneity-calibrated Byzantine-robust CQR.

The implementation mirrors the algorithm in the accompanying manuscript.  It
uses a logistic convolution of the check loss, profiles out site-specific
quantile intercepts, and aggregates site-wise Newton messages by a
coordinate-wise trimmed mean.  Only NumPy is required.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, List, Sequence, Tuple

import numpy as np


Array = np.ndarray


def _log1pexp(x: Array) -> Array:
    """Stable log(1 + exp(x))."""
    out = np.empty_like(x, dtype=float)
    pos = x > 0
    out[pos] = x[pos] + np.log1p(np.exp(-x[pos]))
    out[~pos] = np.log1p(np.exp(x[~pos]))
    return out


def _sigmoid(x: Array) -> Array:
    """Stable logistic sigmoid."""
    out = np.empty_like(x, dtype=float)
    pos = x >= 0
    out[pos] = 1.0 / (1.0 + np.exp(-x[pos]))
    ex = np.exp(x[~pos])
    out[~pos] = ex / (1.0 + ex)
    return out


def soft_threshold(x: Array, level: float) -> Array:
    return np.sign(x) * np.maximum(np.abs(x) - level, 0.0)


def smooth_check(residual: Array, tau: Array, bandwidth: float) -> Array:
    """Logistic-convolution approximation of the check loss."""
    return residual * tau + bandwidth * _log1pexp(-residual / bandwidth)


def fit_intercepts(
    X: Array,
    y: Array,
    beta: Array,
    taus: Sequence[float],
    bandwidth: float,
    initial: Array | None = None,
    max_iter: int = 40,
    tol: float = 1e-9,
) -> Array:
    """Profile the site-specific smoothed quantile intercepts."""
    taus_arr = np.asarray(taus, dtype=float)
    base = y - X @ beta
    if initial is None:
        b = np.quantile(base, taus_arr).astype(float)
    else:
        b = np.asarray(initial, dtype=float).copy()
    q = len(taus_arr)
    for _ in range(max_iter):
        r = base[:, None] - b[None, :]
        cdf_left = _sigmoid(-r / bandwidth)
        psi = taus_arr[None, :] - cdf_left
        w = cdf_left * (1.0 - cdf_left)
        grad = -np.mean(psi, axis=0) / q
        hess = np.mean(w, axis=0) / (q * bandwidth) + 1e-10
        step = grad / hess
        b -= step
        if np.max(np.abs(step)) < tol:
            break
    return b


def profile_components(
    X: Array,
    y: Array,
    beta: Array,
    taus: Sequence[float],
    bandwidth: float,
    intercepts: Array | None = None,
) -> Tuple[float, Array, Array, Array]:
    """Return profiled loss, slope score, profile Hessian, and intercepts."""
    n, p = X.shape
    taus_arr = np.asarray(taus, dtype=float)
    q = len(taus_arr)
    b = fit_intercepts(X, y, beta, taus_arr, bandwidth, initial=intercepts)
    r = y[:, None] - (X @ beta)[:, None] - b[None, :]
    cdf_left = _sigmoid(-r / bandwidth)
    psi = taus_arr[None, :] - cdf_left
    w = cdf_left * (1.0 - cdf_left)

    loss = float(np.mean(smooth_check(r, taus_arr[None, :], bandwidth)))
    grad_beta = -(X.T @ np.sum(psi, axis=1)) / (n * q)

    hbb = np.mean(w, axis=0) / (q * bandwidth) + 1e-10
    hb_beta = np.empty((q, p), dtype=float)
    for ell in range(q):
        hb_beta[ell] = (X.T @ w[:, ell]) / (n * q * bandwidth)
    row_weight = np.sum(w, axis=1) / (n * q * bandwidth)
    h_beta_beta = X.T @ (X * row_weight[:, None])
    schur = h_beta_beta - hb_beta.T @ (hb_beta / hbb[:, None])
    schur = 0.5 * (schur + schur.T)
    return loss, grad_beta, schur, b


def fit_profile_scqr(
    X: Array,
    y: Array,
    taus: Sequence[float],
    bandwidth: float,
    penalty: float,
    beta0: Array | None = None,
    ridge: float = 1e-4,
    max_iter: int = 250,
    tol: float = 2e-6,
) -> Array:
    """Fit a site-level penalized smoothed CQR by profiled proximal steps."""
    p = X.shape[1]
    beta = np.zeros(p) if beta0 is None else np.asarray(beta0, dtype=float).copy()
    b = None
    previous_obj = np.inf
    for _ in range(max_iter):
        loss, grad, hess, b = profile_components(
            X, y, beta, taus, bandwidth, intercepts=b
        )
        try:
            largest = float(np.linalg.eigvalsh(hess)[-1])
        except np.linalg.LinAlgError:
            largest = float(np.linalg.norm(hess, ord=np.inf))
        lipschitz = max(largest + ridge, 1e-3)
        candidate = soft_threshold(beta - grad / lipschitz, penalty / lipschitz)
        obj = loss + penalty * float(np.sum(np.abs(beta)))
        # Conservative backtracking protects against a poor local Hessian.
        for _bt in range(12):
            cand_loss, _, _, cand_b = profile_components(
                X, y, candidate, taus, bandwidth, intercepts=b
            )
            cand_obj = cand_loss + penalty * float(np.sum(np.abs(candidate)))
            if cand_obj <= obj + 1e-10:
                b = cand_b
                break
            lipschitz *= 2.0
            candidate = soft_threshold(beta - grad / lipschitz, penalty / lipschitz)
        change = float(np.max(np.abs(candidate - beta)))
        beta = candidate
        if change < tol or abs(previous_obj - cand_obj) < tol * max(1.0, abs(cand_obj)):
            break
        previous_obj = cand_obj
    return beta


def fit_oracle_profile(
    sites: Sequence[Tuple[Array, Array]],
    taus: Sequence[float],
    bandwidth: float,
    penalty: float,
    beta0: Array | None = None,
    max_iter: int = 300,
    tol: float = 2e-6,
) -> Array:
    """Infeasible pooled-honest benchmark with site-specific intercepts."""
    p = sites[0][0].shape[1]
    beta = np.zeros(p) if beta0 is None else np.asarray(beta0, dtype=float).copy()
    total_n = float(sum(len(y) for _, y in sites))
    intercepts: List[Array | None] = [None] * len(sites)
    previous_obj = np.inf
    for _ in range(max_iter):
        grad = np.zeros(p)
        hess = np.zeros((p, p))
        loss = 0.0
        for k, (X, y) in enumerate(sites):
            lk, gk, hk, bk = profile_components(
                X, y, beta, taus, bandwidth, intercepts[k]
            )
            wk = len(y) / total_n
            loss += wk * lk
            grad += wk * gk
            hess += wk * hk
            intercepts[k] = bk
        try:
            lipschitz = max(float(np.linalg.eigvalsh(hess)[-1]), 1e-3)
        except np.linalg.LinAlgError:
            lipschitz = max(float(np.linalg.norm(hess, ord=np.inf)), 1e-3)
        candidate = soft_threshold(beta - grad / lipschitz, penalty / lipschitz)
        obj = loss + penalty * float(np.sum(np.abs(beta)))
        for _bt in range(12):
            cand_loss = 0.0
            cand_intercepts: List[Array] = []
            for X, y in sites:
                lk, _, _, bk = profile_components(X, y, candidate, taus, bandwidth)
                cand_loss += (len(y) / total_n) * lk
                cand_intercepts.append(bk)
            cand_obj = cand_loss + penalty * float(np.sum(np.abs(candidate)))
            if cand_obj <= obj + 1e-10:
                intercepts = cand_intercepts
                break
            lipschitz *= 2.0
            candidate = soft_threshold(beta - grad / lipschitz, penalty / lipschitz)
        change = float(np.max(np.abs(candidate - beta)))
        beta = candidate
        if change < tol or abs(previous_obj - cand_obj) < tol * max(1.0, abs(cand_obj)):
            break
        previous_obj = cand_obj
    return beta


def coordinate_trimmed_mean(messages: Array, trim_fraction: float) -> Array:
    """Coordinate-wise symmetric trimmed mean."""
    m = messages.shape[0]
    b = int(np.floor(trim_fraction * m))
    if 2 * b >= m:
        raise ValueError("trim_fraction must be below one half")
    ordered = np.sort(messages, axis=0)
    return np.mean(ordered[b : m - b], axis=0)


def attack_messages(
    honest_messages: Array,
    n_byzantine: int,
    attack: str,
    rng: np.random.Generator,
    strength: float = 4.0,
) -> Array:
    """Construct Byzantine messages, including a heterogeneity-mimicking attack."""
    if n_byzantine <= 0:
        return np.empty((0, honest_messages.shape[1]))
    center = np.median(honest_messages, axis=0)
    scale = np.std(honest_messages, axis=0, ddof=1)
    scale = np.maximum(scale, 1e-3)
    p = honest_messages.shape[1]
    if attack == "sign":
        bad = np.tile(-strength * center, (n_byzantine, 1))
    elif attack == "gaussian":
        bad = rng.normal(0.0, strength * np.max(scale), size=(n_byzantine, p))
    elif attack == "alie":
        direction = np.sign(center)
        direction[direction == 0] = 1.0
        bad = np.tile(center - 1.5 * scale * direction, (n_byzantine, 1))
    elif attack == "mimic":
        # Values are placed near the honest coordinatewise center; depending on
        # the realized sample, they need not lie inside every honest range.
        direction = np.sign(np.mean(honest_messages, axis=0) - center)
        direction[direction == 0] = rng.choice([-1.0, 1.0], size=np.sum(direction == 0))
        bad = np.tile(center + 0.9 * scale * direction, (n_byzantine, 1))
    else:
        raise ValueError(f"unknown attack: {attack}")
    if n_byzantine > 1:
        bad += rng.normal(0.0, 0.02, size=bad.shape) * scale
    return bad


def newton_message(
    X: Array,
    y: Array,
    beta: Array,
    taus: Sequence[float],
    bandwidth: float,
    ridge: float,
) -> Array:
    """Site-wise curvature-calibrated Newton message."""
    _, grad, hess, _ = profile_components(X, y, beta, taus, bandwidth)
    regularized = hess + ridge * np.eye(hess.shape[0])
    try:
        step = np.linalg.solve(regularized, grad)
    except np.linalg.LinAlgError:
        step = np.linalg.pinv(regularized, rcond=1e-7) @ grad
    # A deterministic trust region stabilizes the numerical experiments.
    # The current theory studies the uncapped message and does not establish
    # that this safeguard is inactive with high probability.
    radius = 2.5 * max(1.0, float(np.linalg.norm(beta)))
    norm_step = float(np.linalg.norm(step))
    if norm_step > radius:
        step *= radius / norm_step
    return beta - step


@dataclass
class DistributedFit:
    beta: Array
    path: Array
    local_estimates: Array


def fit_hc_rcqr(
    sites: Sequence[Tuple[Array, Array]],
    taus: Sequence[float],
    bandwidth: float,
    local_penalty: float,
    threshold: float,
    byzantine_fraction: float,
    trim_fraction: float,
    attack: str,
    rng: np.random.Generator,
    rounds: int = 5,
    ridge: float = 0.06,
) -> DistributedFit:
    """Fit the proposed heterogeneity-calibrated robust distributed estimator."""
    m = len(sites)
    n_bad = int(np.floor(byzantine_fraction * m))
    n_honest = m - n_bad
    local = np.vstack(
        [
            fit_profile_scqr(X, y, taus, bandwidth, local_penalty, max_iter=180)
            for X, y in sites[:n_honest]
        ]
    )
    bad_local = attack_messages(local, n_bad, attack, rng)
    received = np.vstack([local, bad_local])
    rng.shuffle(received, axis=0)
    beta = np.median(received, axis=0)
    beta = soft_threshold(beta, threshold * 1.5)
    path = [beta.copy()]
    for t in range(rounds):
        honest_messages = np.vstack(
            [newton_message(X, y, beta, taus, bandwidth, ridge) for X, y in sites[:n_honest]]
        )
        bad = attack_messages(honest_messages, n_bad, attack, rng)
        received = np.vstack([honest_messages, bad])
        rng.shuffle(received, axis=0)
        aggregate = coordinate_trimmed_mean(received, trim_fraction)
        level = threshold * (1.0 + 0.5 ** (t + 1))
        beta = soft_threshold(aggregate, level)
        path.append(beta.copy())
    return DistributedFit(beta=beta, path=np.vstack(path), local_estimates=local)


def fit_uncalibrated_rcqr(
    sites: Sequence[Tuple[Array, Array]],
    taus: Sequence[float],
    bandwidth: float,
    threshold: float,
    byzantine_fraction: float,
    trim_fraction: float,
    attack: str,
    rng: np.random.Generator,
    rounds: int = 30,
    step_size: float = 0.35,
) -> Array:
    """Robust raw-score aggregation baseline without heterogeneity calibration."""
    m = len(sites)
    n_bad = int(np.floor(byzantine_fraction * m))
    n_honest = m - n_bad
    beta = np.zeros(sites[0][0].shape[1])
    for _ in range(rounds):
        gradients = []
        for X, y in sites[:n_honest]:
            _, grad, _, _ = profile_components(X, y, beta, taus, bandwidth)
            gradients.append(grad)
        honest = np.vstack(gradients)
        bad = attack_messages(honest, n_bad, attack, rng)
        received = np.vstack([honest, bad])
        rng.shuffle(received, axis=0)
        grad = coordinate_trimmed_mean(received, trim_fraction)
        beta = soft_threshold(beta - step_size * grad, step_size * threshold)
    return beta


def local_aggregate_baselines(
    local_honest: Array,
    byzantine_fraction: float,
    attack: str,
    rng: np.random.Generator,
) -> Tuple[Array, Array]:
    """Return naive mean and coordinatewise median of attacked local estimates."""
    n_honest = local_honest.shape[0]
    m = int(round(n_honest / (1.0 - byzantine_fraction))) if byzantine_fraction > 0 else n_honest
    n_bad = max(0, m - n_honest)
    bad = attack_messages(local_honest, n_bad, attack, rng)
    received = np.vstack([local_honest, bad])
    rng.shuffle(received, axis=0)
    return np.mean(received, axis=0), np.median(received, axis=0)


def composite_pinball_loss(
    sites: Sequence[Tuple[Array, Array]],
    beta: Array,
    taus: Sequence[float],
    train_sites_for_intercepts: Sequence[Tuple[Array, Array]] | None = None,
) -> float:
    """Evaluate ordinary (unsmoothed) composite check loss."""
    taus_arr = np.asarray(taus, dtype=float)
    if train_sites_for_intercepts is None:
        train_sites_for_intercepts = sites
    total = 0.0
    count = 0
    for (X, y), (Xtr, ytr) in zip(sites, train_sites_for_intercepts):
        b = np.quantile(ytr - Xtr @ beta, taus_arr)
        r = y[:, None] - (X @ beta)[:, None] - b[None, :]
        loss = r * (taus_arr[None, :] - (r < 0).astype(float))
        total += float(np.sum(loss))
        count += loss.size
    return total / max(count, 1)


def support_metrics(beta_hat: Array, beta_true: Array, threshold: float = 1e-8) -> Tuple[float, float]:
    selected = np.flatnonzero(np.abs(beta_hat) > threshold)
    truth = np.flatnonzero(np.abs(beta_true) > threshold)
    selected_set, truth_set = set(selected.tolist()), set(truth.tolist())
    tp = len(selected_set & truth_set)
    precision = tp / max(len(selected_set), 1)
    recall = tp / max(len(truth_set), 1)
    return precision, recall
