"""Monte Carlo experiments for the HC-RCQR manuscript.

The script writes replicate-level results and a compact summary table.  It is
deterministic given the master seed and uses no packages beyond NumPy.
"""

from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path

import numpy as np

from hcrcqr import (
    attack_messages,
    fit_hc_rcqr,
    fit_oracle_profile,
    fit_uncalibrated_rcqr,
    support_metrics,
)


def generate_sites(
    rng: np.random.Generator,
    m: int,
    n: int,
    p: int,
    beta: np.ndarray,
    heterogeneity: float,
) -> list[tuple[np.ndarray, np.ndarray]]:
    sites = []
    base_direction = np.linspace(-1.0, 1.0, p)
    for k in range(m):
        phase = 2.0 * math.pi * k / m
        scale = np.exp(heterogeneity * 0.45 * np.sin(phase + np.arange(p) / 4.0))
        rho = 0.05 + 0.50 * heterogeneity * (0.5 + 0.5 * np.cos(phase))
        common = rng.normal(size=(n, 1))
        innovation = rng.normal(size=(n, p))
        X = scale[None, :] * (math.sqrt(max(1.0 - rho * rho, 0.05)) * innovation + rho * common)
        mean_shift = heterogeneity * 0.35 * math.sin(phase) * base_direction
        X += mean_shift[None, :]
        X -= np.mean(X, axis=0, keepdims=True)
        col_sd = np.std(X, axis=0, ddof=1)
        X /= np.maximum(col_sd, 0.25)[None, :]

        site_scale = 0.65 + 0.75 * (0.5 + 0.5 * math.sin(phase + 0.7)) * heterogeneity
        site_location = 0.9 * heterogeneity * math.cos(phase - 0.4)
        err = rng.standard_t(df=3.0, size=n) / math.sqrt(3.0)
        y = site_location + X @ beta + site_scale * err
        sites.append((X.astype(float), y.astype(float)))
    return sites


def evaluate(beta_hat: np.ndarray, beta: np.ndarray) -> tuple[float, float, float, float]:
    l2 = float(np.linalg.norm(beta_hat - beta))
    l1 = float(np.sum(np.abs(beta_hat - beta)))
    precision, recall = support_metrics(beta_hat, beta, threshold=0.08)
    return l2, l1, precision, recall


def run_one(
    seed: int,
    heterogeneity: float,
    alpha: float,
    attack: str,
    m: int,
    n: int,
    p: int,
    s: int,
) -> list[dict[str, float | int | str]]:
    rng = np.random.default_rng(seed)
    beta = np.zeros(p)
    # The fifth coefficient is deliberately near the detection boundary so
    # support recovery is not mechanically perfect in every method.
    beta[:s] = np.array([1.00, -0.82, 0.66, -0.46, 0.24])[:s]
    sites = generate_sites(rng, m, n, p, beta, heterogeneity)
    n_bad = int(np.floor(alpha * m))
    n_honest = m - n_bad
    honest_sites = sites[:n_honest]
    taus = (0.25, 0.50, 0.75)
    bandwidth = 0.24
    local_penalty = 0.24 * math.sqrt(math.log(p) / n)
    threshold = 0.035 + 0.035 * alpha
    trim = min(max(alpha + 0.05, 0.05), 0.40)

    hc = fit_hc_rcqr(
        sites,
        taus,
        bandwidth,
        local_penalty,
        threshold,
        alpha,
        trim,
        attack,
        rng,
        rounds=4,
        ridge=0.08,
    )
    bad_local = attack_messages(hc.local_estimates, n_bad, attack, rng)
    received_local = np.vstack([hc.local_estimates, bad_local])
    beta_mean = np.mean(received_local, axis=0)
    beta_median = np.median(received_local, axis=0)
    beta_median[np.abs(beta_median) < threshold] = 0.0
    beta_uncal = fit_uncalibrated_rcqr(
        sites,
        taus,
        bandwidth,
        threshold,
        alpha,
        trim,
        attack,
        rng,
        rounds=28,
        step_size=0.25,
    )
    beta_oracle = fit_oracle_profile(
        honest_sites,
        taus,
        bandwidth,
        penalty=0.012,
        beta0=hc.beta,
        max_iter=180,
    )

    estimates = {
        "Oracle pooled": beta_oracle,
        "Naive mean": beta_mean,
        "Local median": beta_median,
        "Robust raw score": beta_uncal,
        "HC-RCQR": hc.beta,
    }
    rows = []
    for method, estimate in estimates.items():
        l2, l1, precision, recall = evaluate(estimate, beta)
        selected_set = set(np.flatnonzero(np.abs(estimate) > 0.08).tolist())
        truth_set = set(np.flatnonzero(np.abs(beta) > 0.08).tolist())
        rows.append(
            {
                "seed": seed,
                "heterogeneity": heterogeneity,
                "alpha": alpha,
                "attack": attack,
                "method": method,
                "l2": l2,
                "l1": l1,
                "precision": precision,
                "recall": recall,
                "selected": int(np.sum(np.abs(estimate) > 0.08)),
                "exact_support": float(selected_set == truth_set),
            }
        )
    return rows


def summarize(rows: list[dict[str, float | int | str]]) -> list[dict[str, float | str]]:
    groups: dict[tuple[float, float, str, str], list[dict[str, float | int | str]]] = {}
    for row in rows:
        key = (
            float(row["heterogeneity"]),
            float(row["alpha"]),
            str(row["attack"]),
            str(row["method"]),
        )
        groups.setdefault(key, []).append(row)
    summary = []
    for key, values in sorted(groups.items()):
        h, a, attack, method = key
        item: dict[str, float | str] = {
            "heterogeneity": h,
            "alpha": a,
            "attack": attack,
            "method": method,
        }
        for metric in ("l2", "l1", "precision", "recall", "selected", "exact_support"):
            arr = np.asarray([float(v[metric]) for v in values])
            item[f"{metric}_mean"] = float(np.mean(arr))
            item[f"{metric}_se"] = float(np.std(arr, ddof=1) / math.sqrt(len(arr))) if len(arr) > 1 else 0.0
        summary.append(item)
    return summary


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--reps", type=int, default=50)
    parser.add_argument("--output", type=Path, default=Path("../results"))
    parser.add_argument("--quick", action="store_true")
    args = parser.parse_args()

    m, n, p, s = (12, 70, 24, 5) if args.quick else (20, 90, 30, 5)
    settings = []
    for h in (0.0, 0.5, 1.0):
        settings.append((h, 0.20, "sign"))
    for a in (0.0, 0.10, 0.20):
        settings.append((0.8, a, "mimic"))

    rows: list[dict[str, float | int | str]] = []
    for setting_id, (h, alpha, attack) in enumerate(settings):
        for rep in range(args.reps):
            seed = 20260907 + 1000 * setting_id + rep
            rows.extend(run_one(seed, h, alpha, attack, m, n, p, s))
            print(
                f"completed setting={setting_id + 1}/{len(settings)} rep={rep + 1}/{args.reps}",
                flush=True,
            )
    summary = summarize(rows)
    write_csv(args.output / "simulation_replicates.csv", rows)
    write_csv(args.output / "simulation_summary.csv", summary)


if __name__ == "__main__":
    main()
