"""Reproducible heterogeneous real-data experiment on UCI Bike Sharing.

Monthly shards act as distributed sites.  The response is log(1 + hourly
rentals), and the evaluation is performed only on honest sites after an
80/20 time-ordered split within each site. This is not a globally
chronological forecasting experiment.
"""

from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path

import numpy as np
import pandas as pd

from hcrcqr import (
    attack_messages,
    composite_pinball_loss,
    fit_hc_rcqr,
    fit_oracle_profile,
    fit_uncalibrated_rcqr,
)


TAUS = (0.25, 0.50, 0.75)


def prepare_sites(csv_path: Path) -> tuple[list[tuple[np.ndarray, np.ndarray]], list[tuple[np.ndarray, np.ndarray]], list[str]]:
    data = pd.read_csv(csv_path)
    response = np.log1p(data["cnt"].to_numpy(dtype=float))

    continuous = data[["temp", "atemp", "hum", "windspeed"]].copy()
    binary = data[["holiday", "workingday"]].astype(float)
    hour = pd.get_dummies(data["hr"], prefix="hour", drop_first=True, dtype=float)
    weekday = pd.get_dummies(data["weekday"], prefix="weekday", drop_first=True, dtype=float)
    weather = pd.get_dummies(data["weathersit"], prefix="weather", drop_first=True, dtype=float)
    features = pd.concat([continuous, binary, hour, weekday, weather], axis=1)
    feature_names = features.columns.tolist()
    X_all = features.to_numpy(dtype=float)
    site_id = (12 * data["yr"].to_numpy(dtype=int) + data["mnth"].to_numpy(dtype=int) - 1)

    train_indices: list[np.ndarray] = []
    test_indices: list[np.ndarray] = []
    for site in sorted(np.unique(site_id)):
        idx = np.flatnonzero(site_id == site)
        idx = idx[np.argsort(data.loc[idx, "instant"].to_numpy())]
        cut = int(math.floor(0.80 * len(idx)))
        train_indices.append(idx[:cut])
        test_indices.append(idx[cut:])

    pooled_train = np.concatenate(train_indices)
    means = np.mean(X_all[pooled_train, :4], axis=0)
    scales = np.std(X_all[pooled_train, :4], axis=0, ddof=1)
    X_all[:, :4] = (X_all[:, :4] - means[None, :]) / np.maximum(scales, 1e-8)[None, :]

    train_sites = [(X_all[idx].copy(), response[idx].copy()) for idx in train_indices]
    test_sites = [(X_all[idx].copy(), response[idx].copy()) for idx in test_indices]
    return train_sites, test_sites, feature_names


def prediction_metrics(
    beta: np.ndarray,
    train_sites: list[tuple[np.ndarray, np.ndarray]],
    test_sites: list[tuple[np.ndarray, np.ndarray]],
) -> tuple[float, float, float, float]:
    pinball = composite_pinball_loss(test_sites, beta, TAUS, train_sites)
    absolute = []
    covered = []
    widths = []
    for (Xtr, ytr), (Xte, yte) in zip(train_sites, test_sites):
        intercepts = np.quantile(ytr - Xtr @ beta, np.asarray(TAUS))
        pred = Xte @ beta
        absolute.extend(np.abs(yte - (pred + intercepts[1])).tolist())
        lower, upper = pred + intercepts[0], pred + intercepts[2]
        covered.extend(((yte >= lower) & (yte <= upper)).astype(float).tolist())
        widths.extend((upper - lower).tolist())
    return pinball, float(np.mean(absolute)), float(np.mean(covered)), float(np.mean(widths))


def run_assignment(
    seed: int,
    train_sites: list[tuple[np.ndarray, np.ndarray]],
    test_sites: list[tuple[np.ndarray, np.ndarray]],
    alpha: float,
    attack: str,
) -> list[dict[str, float | int | str]]:
    rng = np.random.default_rng(seed)
    m = len(train_sites)
    n_bad = int(np.floor(alpha * m))
    order = rng.permutation(m)
    honest_idx = order[: m - n_bad]
    bad_idx = order[m - n_bad :]
    ordered_train = [train_sites[i] for i in np.concatenate([honest_idx, bad_idx])]
    honest_train = [train_sites[i] for i in honest_idx]
    honest_test = [test_sites[i] for i in honest_idx]

    p = ordered_train[0][0].shape[1]
    median_n = float(np.median([len(y) for X, y in honest_train]))
    local_penalty = 0.20 * math.sqrt(math.log(p) / median_n)
    threshold = 0.018 + 0.030 * alpha
    trim = min(max(alpha + 0.05, 0.05), 0.40)
    hc = fit_hc_rcqr(
        ordered_train,
        TAUS,
        bandwidth=0.18,
        local_penalty=local_penalty,
        threshold=threshold,
        byzantine_fraction=alpha,
        trim_fraction=trim,
        attack=attack,
        rng=rng,
        rounds=5,
        ridge=0.055,
    )
    bad_local = attack_messages(hc.local_estimates, n_bad, attack, rng)
    local_received = np.vstack([hc.local_estimates, bad_local])
    naive = np.mean(local_received, axis=0)
    local_median = np.median(local_received, axis=0)
    local_median[np.abs(local_median) < threshold] = 0.0
    raw = fit_uncalibrated_rcqr(
        ordered_train,
        TAUS,
        bandwidth=0.18,
        threshold=threshold,
        byzantine_fraction=alpha,
        trim_fraction=trim,
        attack=attack,
        rng=rng,
        rounds=35,
        step_size=0.18,
    )
    oracle = fit_oracle_profile(
        honest_train,
        TAUS,
        bandwidth=0.18,
        penalty=0.004,
        beta0=hc.beta,
        max_iter=220,
    )
    methods = {
        "Oracle pooled": oracle,
        "Naive mean": naive,
        "Local median": local_median,
        "Robust raw score": raw,
        "HC-RCQR": hc.beta,
    }
    rows = []
    for method, beta in methods.items():
        pinball, mae, coverage, width = prediction_metrics(beta, honest_train, honest_test)
        rows.append(
            {
                "seed": seed,
                "alpha": alpha,
                "attack": attack,
                "method": method,
                "pinball": pinball,
                "median_mae": mae,
                "central50_coverage": coverage,
                "central50_width": width,
                "selected": int(np.sum(np.abs(beta) > 0.03)),
            }
        )
    return rows


def summarize(rows: list[dict]) -> list[dict]:
    grouped: dict[tuple[float, str, str], list[dict]] = {}
    for row in rows:
        key = (float(row["alpha"]), str(row["attack"]), str(row["method"]))
        grouped.setdefault(key, []).append(row)
    output = []
    for (alpha, attack, method), values in sorted(grouped.items()):
        result = {"alpha": alpha, "attack": attack, "method": method}
        for metric in ("pinball", "median_mae", "central50_coverage", "central50_width", "selected"):
            x = np.asarray([float(v[metric]) for v in values])
            result[f"{metric}_mean"] = float(np.mean(x))
            result[f"{metric}_se"] = float(np.std(x, ddof=1) / math.sqrt(len(x))) if len(x) > 1 else 0.0
        output.append(result)
    return output


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--reps", type=int, default=10)
    parser.add_argument("--output", type=Path, default=Path("../results"))
    args = parser.parse_args()

    train_sites, test_sites, feature_names = prepare_sites(args.data)
    rows = []
    settings = [(0.0, "mimic"), (1.0 / 6.0, "sign"), (1.0 / 6.0, "mimic")]
    for setting_id, (alpha, attack) in enumerate(settings):
        for rep in range(args.reps):
            seed = 20261001 + 100 * setting_id + rep
            rows.extend(run_assignment(seed, train_sites, test_sites, alpha, attack))
            print(
                f"completed real-data setting={setting_id + 1}/{len(settings)} rep={rep + 1}/{args.reps}",
                flush=True,
            )
    write_csv(args.output / "bike_replicates.csv", rows)
    write_csv(args.output / "bike_summary.csv", summarize(rows))
    (args.output / "bike_feature_names.txt").write_text("\n".join(feature_names) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
