"""Small deterministic checks for the HC-RCQR reference implementation."""

from __future__ import annotations

import unittest

import numpy as np

from hcrcqr import (
    coordinate_trimmed_mean,
    fit_hc_rcqr,
    profile_components,
    soft_threshold,
)


class TestCoreRoutines(unittest.TestCase):
    def test_soft_threshold(self) -> None:
        value = np.array([-2.0, -0.2, 0.0, 0.4, 3.0])
        expected = np.array([-1.5, 0.0, 0.0, 0.0, 2.5])
        np.testing.assert_allclose(soft_threshold(value, 0.5), expected)

    def test_trimmed_mean_removes_extremes(self) -> None:
        messages = np.array(
            [
                [0.9, 2.1],
                [1.0, 2.0],
                [1.1, 1.9],
                [100.0, -100.0],
            ]
        )
        result = coordinate_trimmed_mean(messages, 0.25)
        np.testing.assert_allclose(result, np.array([1.05, 1.95]))

    def test_profile_hessian_is_symmetric(self) -> None:
        rng = np.random.default_rng(7)
        X = rng.normal(size=(120, 5))
        beta = np.array([0.8, -0.5, 0.0, 0.0, 0.2])
        y = X @ beta + rng.standard_t(df=4, size=120)
        _, grad, hess, intercepts = profile_components(
            X, y, np.zeros(5), (0.25, 0.5, 0.75), 0.25
        )
        self.assertEqual(grad.shape, (5,))
        self.assertEqual(intercepts.shape, (3,))
        np.testing.assert_allclose(hess, hess.T, atol=1e-10)
        self.assertGreater(float(np.linalg.eigvalsh(hess)[0]), -1e-9)

    def test_distributed_fit_is_finite_and_reproducible(self) -> None:
        rng = np.random.default_rng(19)
        sites = []
        true_beta = np.array([0.7, -0.45, 0.0, 0.0])
        for k in range(6):
            X = rng.normal(size=(70, 4))
            y = 0.2 * k + X @ true_beta + (0.7 + 0.1 * k) * rng.standard_t(4, 70)
            sites.append((X, y))

        kwargs = dict(
            sites=sites,
            taus=(0.25, 0.5, 0.75),
            bandwidth=0.25,
            local_penalty=0.05,
            threshold=0.02,
            byzantine_fraction=1.0 / 6.0,
            trim_fraction=1.0 / 3.0,
            attack="sign",
            rounds=2,
            ridge=0.08,
        )
        fit1 = fit_hc_rcqr(rng=np.random.default_rng(123), **kwargs)
        fit2 = fit_hc_rcqr(rng=np.random.default_rng(123), **kwargs)
        self.assertTrue(np.all(np.isfinite(fit1.beta)))
        self.assertEqual(fit1.path.shape, (3, 4))
        np.testing.assert_allclose(fit1.beta, fit2.beta)


if __name__ == "__main__":
    unittest.main()
