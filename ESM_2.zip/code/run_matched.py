"""Paired calibration comparison; all settings are fixed before evaluation."""
import os
for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[key] = '1'
import argparse
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import numpy as np
from hcrcqr import fit_profile_scqr, profile_components, attack_messages, soft_threshold, coordinate_trimmed_mean
from run_simulation import generate_sites, write_csv

def run(job):
    seed, heterogeneity, attack = job
    m, n, p, alpha = 20, 90, 30, .2
    truth = np.zeros(p)
    truth[:5] = [1, -.82, .66, -.46, .24]
    sites = generate_sites(np.random.default_rng(seed), m, n, p, truth, heterogeneity)[:16]
    taus, h, ridge, trim, floor = (.25, .5, .75), .24, .08, .25, .042
    local = np.vstack([fit_profile_scqr(x, y, taus, h, .24*np.sqrt(np.log(p)/n), max_iter=180) for x,y in sites])
    bad = attack_messages(local, 4, attack, np.random.default_rng(seed+100000))
    initial = soft_threshold(np.median(np.vstack([local,bad]), axis=0), 1.5*floor)
    rows = []
    for name, scalar in [('local', None), ('scalar1', 1.), ('scalar4', 4.), ('scalar8', 8.)]:
        beta = initial.copy()
        for t in range(4):
            messages = []
            capped = 0
            for x,y in sites:
                _,g,a,_ = profile_components(x,y,beta,taus,h)
                step = np.linalg.solve(a+ridge*np.eye(p),g) if scalar is None else scalar*g
                radius = 2.5*max(1.,np.linalg.norm(beta))
                if np.linalg.norm(step)>radius:
                    step *= radius/np.linalg.norm(step)
                    capped += 1
                messages.append(beta-step)
            messages = np.vstack(messages)
            spread = float(np.sqrt(np.mean((messages-messages.mean(axis=0))**2)))
            bad = attack_messages(messages,4,attack,np.random.default_rng(seed+200000+t))
            beta = soft_threshold(coordinate_trimmed_mean(np.vstack([messages,bad]),trim),floor*(1+.5**(t+1)))
            rows.append(dict(seed=seed,heterogeneity=heterogeneity,attack=attack,method=name,round=t+1,l2=float(np.linalg.norm(beta-truth)),honest_spread=spread,capped=capped,initial_l2=float(np.linalg.norm(initial-truth))))
    return rows

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--reps',type=int,default=50)
    parser.add_argument('--workers',type=int,default=4)
    parser.add_argument('--output',type=Path,default=Path('../results'))
    args=parser.parse_args()
    jobs=[(202609150+k*1000+i,h,a) for k,(h,a) in enumerate([(0.,'sign'),(1.,'sign'),(0.,'mimic'),(1.,'mimic')]) for i in range(args.reps)]
    rows=[]
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for i,result in enumerate(pool.map(run,jobs)):
            rows.extend(result)
            if (i+1)%10==0: print(f'{i+1}/{len(jobs)} datasets completed',flush=True)
    write_csv(args.output/'matched_replicates.csv',rows)
    summary=[]
    for h,a in [(0.,'sign'),(1.,'sign'),(0.,'mimic'),(1.,'mimic')]:
        reference={r['seed']:r['l2'] for r in rows if r['heterogeneity']==h and r['attack']==a and r['method']=='local' and r['round']==4}
        for method in ('local','scalar1','scalar4','scalar8'):
            vals=[r for r in rows if r['heterogeneity']==h and r['attack']==a and r['method']==method and r['round']==4]
            errors=np.array([r['l2'] for r in vals])
            difference=np.array([r['l2']-reference[r['seed']] for r in vals])
            summary.append(dict(heterogeneity=h,attack=a,method=method,reps=len(vals),l2_mean=errors.mean(),l2_se=errors.std(ddof=1)/np.sqrt(len(vals)),paired_difference=difference.mean(),paired_se=difference.std(ddof=1)/np.sqrt(len(vals))))
    write_csv(args.output/'matched_summary.csv',summary)
    print(summary,flush=True)

if __name__=='__main__': main()
