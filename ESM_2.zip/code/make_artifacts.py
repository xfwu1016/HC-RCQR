"""Convert raw experiment CSV files into manuscript tables and plot data."""

from __future__ import annotations

import csv
from pathlib import Path


METHOD_ORDER = ["Oracle pooled", "Naive mean", "Local median", "Robust raw score", "HC-RCQR"]
SHORT = {
    "Oracle pooled": "Oracle",
    "Naive mean": "Mean",
    "Local median": "Med-L",
    "Robust raw score": "RTM-score",
    "HC-RCQR": "HC-RCQR",
}


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def index(rows: list[dict[str, str]], keys: tuple[str, ...]) -> dict[tuple[str, ...], dict[str, str]]:
    return {tuple(row[k] for k in keys): row for row in rows}


def fmt(row: dict[str, str], metric: str, digits: int = 3) -> str:
    mean = float(row[f"{metric}_mean"])
    se = float(row[f"{metric}_se"])
    return f"{mean:.{digits}f} ({se:.{digits}f})"


def write_sim_table(rows: list[dict[str, str]], output: Path) -> None:
    lookup = index(rows, ("heterogeneity", "alpha", "attack", "method"))
    lines = [
        r"\begin{tabular}{llrrrr}",
        r"\toprule",
        r"Setting & Method & $\ell_2$ error & $\ell_1$ error & Exact support & Selected \\",
        r"\midrule",
    ]
    selected_settings = [
        ("0.0", "0.2", "sign", r"$H=0,\ \alpha=.2$") ,
        ("0.5", "0.2", "sign", r"$H=.5,\ \alpha=.2$") ,
        ("1.0", "0.2", "sign", r"$H=1,\ \alpha=.2$") ,
        ("0.8", "0.2", "mimic", r"$H=.8,\ \alpha=.2$ (mimic)"),
    ]
    for setting_no, (h, a, attack, label) in enumerate(selected_settings):
        for method_no, method in enumerate(METHOD_ORDER):
            row = lookup[(h, a, attack, method)]
            setting = label if method_no == 0 else ""
            lines.append(
                f"{setting} & {SHORT[method]} & {fmt(row, 'l2')} & {fmt(row, 'l1')} & "
                f"{float(row['exact_support_mean']):.2f} & {float(row['selected_mean']):.2f} \\\\"
            )
        if setting_no < len(selected_settings) - 1:
            lines.append(r"\addlinespace[2pt]")
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    output.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_bike_table(rows: list[dict[str, str]], output: Path) -> None:
    lookup = index(rows, ("alpha", "attack", "method"))
    lines = [
        r"\begin{tabular}{llrrr}",
        r"\toprule",
        r"Attack & Method & Composite loss & Median MAE & 50\% coverage \\",
        r"\midrule",
    ]
    settings = [
        ("0.0", "mimic", "None"),
        ("0.16666666666666666", "sign", "Sign reversal"),
        ("0.16666666666666666", "mimic", "Heterogeneity-mimic"),
    ]
    for setting_no, (a, attack, label) in enumerate(settings):
        for method_no, method in enumerate(METHOD_ORDER):
            row = lookup[(a, attack, method)]
            attack_label = label if method_no == 0 else ""
            lines.append(
                f"{attack_label} & {SHORT[method]} & {fmt(row, 'pinball')} & "
                f"{fmt(row, 'median_mae')} & {float(row['central50_coverage_mean']):.3f} \\\\"
            )
        if setting_no < len(settings) - 1:
            lines.append(r"\addlinespace[2pt]")
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    output.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_plot_data(rows: list[dict[str, str]], outdir: Path) -> None:
    lookup = index(rows, ("heterogeneity", "alpha", "attack", "method"))
    with (outdir / "plot_heterogeneity.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["x"] + [SHORT[m] for m in METHOD_ORDER])
        for h in ("0.0", "0.5", "1.0"):
            writer.writerow([h] + [lookup[(h, "0.2", "sign", m)]["l2_mean"] for m in METHOD_ORDER])
    with (outdir / "plot_alpha.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["x"] + [SHORT[m] for m in METHOD_ORDER])
        for a in ("0.0", "0.1", "0.2"):
            writer.writerow([a] + [lookup[("0.8", a, "mimic", m)]["l2_mean"] for m in METHOD_ORDER])


def write_support_plot_data(rows: list[dict[str, str]], outdir: Path) -> None:
    """Write exact-support frequencies for the complementary simulation plot."""
    lookup = index(rows, ("heterogeneity", "alpha", "attack", "method"))
    with (outdir / "plot_support_heterogeneity.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["x"] + [SHORT[m] for m in METHOD_ORDER])
        for h in ("0.0", "0.5", "1.0"):
            writer.writerow([h] + [lookup[(h, "0.2", "sign", m)]["exact_support_mean"] for m in METHOD_ORDER])
    with (outdir / "plot_support_alpha.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["x"] + [SHORT[m] for m in METHOD_ORDER])
        for a in ("0.0", "0.1", "0.2"):
            writer.writerow([a] + [lookup[("0.8", a, "mimic", m)]["exact_support_mean"] for m in METHOD_ORDER])


def write_bike_plot_data(rows: list[dict[str, str]], outdir: Path) -> None:
    """Write the two application metrics used in the manuscript figure."""
    lookup = index(rows, ("alpha", "attack", "method"))
    settings = [
        ("0.0", "mimic"),
        ("0.16666666666666666", "sign"),
        ("0.16666666666666666", "mimic"),
    ]
    for metric, filename in (("pinball", "plot_bike_loss.csv"), ("central50_width", "plot_bike_width.csv")):
        with (outdir / filename).open("w", newline="", encoding="utf-8") as handle:
            writer = csv.writer(handle)
            writer.writerow(["x"] + [SHORT[m] for m in METHOD_ORDER])
            for x, (alpha, attack) in enumerate(settings):
                writer.writerow([x] + [lookup[(alpha, attack, m)][f"{metric}_mean"] for m in METHOD_ORDER])


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    result_dir = root / "results"
    submission_dir = root / "submission"
    figure_dir = root / "figure_data"
    submission_dir.mkdir(parents=True, exist_ok=True)
    figure_dir.mkdir(parents=True, exist_ok=True)
    sim = read_rows(result_dir / "simulation_summary.csv")
    bike = read_rows(result_dir / "bike_summary.csv")
    write_sim_table(sim, submission_dir / "table_simulation.tex")
    write_bike_table(bike, submission_dir / "table_bike.tex")
    write_plot_data(sim, figure_dir)
    write_support_plot_data(sim, figure_dir)
    write_bike_plot_data(bike, figure_dir)


if __name__ == "__main__":
    main()
