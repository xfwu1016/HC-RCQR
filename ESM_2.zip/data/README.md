# UCI Bike Sharing data

The empirical study uses the hourly data from:

Hadi Fanaee-T (2013), *Bike Sharing*, UCI Machine Learning Repository,
<https://doi.org/10.24432/C5W894>.

Download the repository ZIP, extract **hour.csv**, and place that file in this
directory. The analysis expects:

- 17,379 data rows, excluding the header (the actual number in hour.csv);
- the columns documented by UCI, including instant, yr, mnth, hr, temp, atemp,
  hum, windspeed, casual, registered, and cnt;
- no missing values.

For the exact file used in this study, the SHA-256 checksum is
`e03de4ee4ef4dc376ac6e04bf829673c6269e8eba5c60fa121640fa2f829504f`.
The split contains 13,895 training records and 3,484 test records across
24 monthly sites, with 38 encoded predictors.

The script excludes casual and registered because their sum equals the
response cnt; this prevents target leakage. It also performs every
continuous-variable transformation using training records only.
