"""Regenerate high-dimensional tables, plot source, and audit summaries."""
from pathlib import Path
import csv
import json
import argparse
import numpy as np

METRICS=['l2','linf','l1','false_positive','false_negative','exact_support']
def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--results',type=Path,default=Path('../results'))
    parser.add_argument('--artifacts',type=Path,default=Path('../figures'))
    args=parser.parse_args()
    args.artifacts.mkdir(parents=True,exist_ok=True)
    rows=list(csv.DictReader((args.results/'highdim_replicates.csv').open()))
    summary=[]
    keys=sorted({(int(r['setting']),r['method'],int(r['round'])) for r in rows})
    for setting,method,round_no in keys:
        sub=[r for r in rows if int(r['setting'])==setting and r['method']==method and int(r['round'])==round_no]
        record={k:sub[0][k] for k in ['setting','n','p','attack','faults']}
        record.update(method=method,round=round_no,reps=len(sub))
        for key in METRICS:
            values=np.array([float(r[key]) for r in sub])
            record[key+'_mean']=float(values.mean())
            record[key+'_se']=float(values.std(ddof=1)/np.sqrt(len(values)))
        summary.append(record)
    with (args.results/'highdim_summary.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(summary[0]));writer.writeheader();writer.writerows(summary)
    lookup={(int(r['setting']),r['method'],r['round']):r for r in summary}
    attacks={'none':'None','sign':'Sign','mimic':'Mimic'}
    lines=[r'\begin{tabular}{llrrrr}',r'\toprule',
           r'$(n,p)$ & Attack & Dantzig--TM & Unit--TM & $4I$--TM & Dantzig--Mean \\',r'\midrule']
    support=[r'\begin{tabular}{llrrrrr}',r'\toprule',
             r'$(n,p)$ & Attack & Initial & Round 1 & Round 2 & FP (1) & FP (2) \\',r'\midrule']
    pair_rows=[]
    for setting in range(6):
        first=lookup[(setting,'Dantzig-TM',1)]
        cells=[f"$({first['n']},{first['p']})$",attacks[first['attack']]]
        for method in ['Dantzig-TM','Unit-TM','Scalar4-TM','Dantzig-Mean']:
            r=lookup[(setting,method,1)]
            cells.append(f"{r['l2_mean']:.3f} ({r['l2_se']:.3f})")
        lines.append(' & '.join(cells)+r' \\')
        a=lookup[(setting,'Initializer',0)];b=lookup[(setting,'Dantzig-TM',2)]
        support.append(' & '.join(cells[:2]+[f"{r['exact_support_mean']:.2f}" for r in [a,first,b]]+
                                  [f"{r['false_positive_mean']:.2f}" for r in [first,b]])+r' \\')
        # Paired errors use replicate identifiers, not independent-sample SEs.
        for comparator in ['Unit-TM','Scalar4-TM','Dantzig-Mean']:
            diffs=[]
            for rep in sorted({int(r['rep']) for r in rows if int(r['setting'])==setting}):
                subset=[r for r in rows if int(r['setting'])==setting and int(r['rep'])==rep and r['round']=='1']
                indexed={r['method']:float(r['l2']) for r in subset}
                diffs.append(indexed['Dantzig-TM']-indexed[comparator])
            pair_rows.append(dict(setting=setting,comparator=comparator,
                                  mean=float(np.mean(diffs)),se=float(np.std(diffs,ddof=1)/np.sqrt(len(diffs)))))
    for block,name in [(lines,'highdim_table.tex'),(support,'highdim_support_table.tex')]:
        block.extend([r'\bottomrule',r'\end{tabular}'])
        (args.artifacts/name).write_text('\n'.join(block)+'\n',encoding='utf-8')
    with (args.results/'highdim_paired_differences.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(pair_rows[0]));writer.writeheader();writer.writerows(pair_rows)
    # A vector figure with error bars; compile using pdflatex.
    plot=[r'\documentclass[tikz,border=3pt]{standalone}',r'\usepackage{pgfplots}',
          r'\usepgfplotslibrary{groupplots}',r'\pgfplotsset{compat=1.18}',r'\begin{document}',
          r'\begin{tikzpicture}',
          r'\begin{groupplot}[group style={group size=2 by 1,horizontal sep=1.1cm},width=7.3cm,height=5.4cm,',
          r'xlabel={Refinement round},ylabel={Mean $\ell_2$ error},xmin=-.12,xmax=2.12,xtick={0,1,2},',
          r'ymin=0,ymax=.75,grid=major,grid style={gray!20},tick label style={font=\small},',
          r'label style={font=\small},title style={font=\small},legend style={font=\scriptsize,draw=none,fill=none,at={(.98,.98)},anchor=north east}]']
    for offset,title in [(0,r'(a) $n=40,\ p=80$'),(3,r'(b) $n=60,\ p=120$')]:
        plot.append(r'\nextgroupplot[title={'+title+'}]')
        for j,(color,mark,label) in enumerate([('blue!70!black','*','None'),('red!75!black','square*','Sign reversal'),('orange!80!black','triangle*','Mimic')]):
            plot.append(r'\addplot+['+color+',mark='+mark+r',thick,error bars/.cd,y dir=both,y explicit] coordinates {')
            for t in [0,1,2]:
                r=lookup[(offset+j,'Initializer' if t==0 else 'Dantzig-TM',t)]
                plot.append(f"({t},{r['l2_mean']:.9f}) +- (0,{r['l2_se']:.9f})")
            plot.append('};')
            plot.append(r'\addlegendentry{'+label+'}')
    plot.extend([r'\end{groupplot}',r'\end{tikzpicture}',r'\end{document}'])
    (args.artifacts/'highdim_figure.tex').write_text('\n'.join(plot)+'\n',encoding='utf-8')
    diags=list(csv.DictReader((args.results/'highdim_solver_diagnostics.csv').open()))
    audit=dict(replicates=len({(r['setting'],r['rep']) for r in rows}),records=len(rows),
               solver_records=len(diags),
               max_pilot_kkt=max(float(r['pilot_kkt']) for r in diags),
               max_intercept_error=max(float(r['intercept_error']) for r in diags),
               max_residual_excess=max(float(r['dantzig_residual'])-float(r['nu']) for r in diags),
               max_dual_gap=max(float(r['dantzig_dual_gap']) for r in diags),
               max_dual_violation=max(float(r['dantzig_dual_violation']) for r in diags),
               explicit_lp_rows=sum(int(r['dantzig_lp_count']) for r in diags),
               total_inverse_rows=sum(int(r['p']) for r in diags))
    (args.results/'highdim_audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
    print(json.dumps(audit,indent=2))
    print('\n'.join(lines))
    print('\n'.join(support))
    print('Dantzig trajectories (mean l2):')
    for setting in range(6):
        print(setting,[lookup[(setting,'Initializer' if t==0 else 'Dantzig-TM',t)]['l2_mean'] for t in [0,1,2]])

if __name__=='__main__':
    main()
