"""Bounded-design p>n experiments with uncapped rowwise Dantzig calibration.

All coefficients and seeds are preset; no true slopes or fault identities are
used for tuning. Recorded Monte Carlo errors are descriptive, not verification
of the unknown constants in the sufficient finite-sample theorem.
"""
from __future__ import annotations
import os
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[name] = '1'
import argparse
import csv
import json
import time
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
import numpy as np
from scipy.special import expit
from scipy.optimize import brentq, linprog

TAUS = np.array([.25,.5,.75])
H = .4
NU = [.4,.3]
M = 8
GAMMA = .25

def soft(v, threshold):
    return np.sign(v)*np.maximum(np.abs(v)-threshold,0.)

def profile(x,y,beta,h=H,hessian=False):
    n,p = x.shape
    r = y-x@beta
    # Scalar bracketing avoids unstable unconstrained Newton intercept steps.
    b = np.array([brentq(lambda z: expit((z-r)/h).mean()-tau,
                        r.min()-40*h,r.max()+40*h,xtol=1e-11)
                  for tau in TAUS])
    z = expit((b[None,:]-r[:,None])/h)
    score = x.T@(z-TAUS).mean(1)/n
    loss = float(np.mean(TAUS*(r[:,None]-b)+h*np.logaddexp(0,(b-r[:,None])/h)))
    intercept_error = float(np.max(np.abs((z-TAUS).mean(0))))
    if not hessian:
        return loss,score,intercept_error
    a = np.zeros((p,p))
    for ell in range(len(TAUS)):
        weights = z[:,ell]*(1-z[:,ell])/h
        mu = (weights[:,None]*x).sum(0)/weights.sum()
        centered = x-mu
        a += (centered.T*weights)@centered/(n*len(TAUS))
    return loss,score,(a+a.T)/2,intercept_error

def pilot(x,y,penalty,h=H,tol=2e-7,max_iter=6000):
    # FISTA for the convex profiled objective, using a global Lipschitz bound.
    n,p = x.shape
    lip = max(float(np.linalg.eigvalsh(x@x.T)[-1])/(4*h*n),1e-8)
    beta = np.zeros(p)
    accel = beta.copy()
    momentum = 1.
    for iteration in range(1,max_iter+1):
        _,g,_ = profile(x,y,accel,h=h)
        candidate = soft(accel-g/lip,penalty/lip)
        next_momentum = (1+np.sqrt(1+4*momentum*momentum))/2
        accel = candidate+(momentum-1)/next_momentum*(candidate-beta)
        beta = candidate
        momentum = next_momentum
        if iteration % 10 == 0:
            _,g,be = profile(x,y,beta,h=h)
            active = np.abs(beta)>1e-12
            residual = np.maximum(np.abs(g)-penalty,0.)
            residual[active] = np.abs(g[active]+penalty*np.sign(beta[active]))
            kkt = float(residual.max())
            if kkt <= tol:
                return beta,dict(pilot_kkt=kkt,pilot_iterations=iteration,intercept_error=be)
    raise RuntimeError(f'Pilot failed KKT tolerance: {kkt}')

def dantzig(a,nu):
    p = len(a)
    theta = np.zeros_like(a)
    lp_count = 0
    max_gap = 0.
    max_dual = 0.
    a_split = np.hstack([a,-a])
    constraints = np.vstack([a_split,-a_split])
    objective = np.ones(2*p)
    for j in range(p):
        # Exact shortcut: if the diagonal feasible row attains the lower bound
        # (1-nu)/max_l |a[j,l]|, it is already an l1 minimizer.
        diagonal = (1-nu)/a[j,j]
        candidate = np.zeros(p)
        candidate[j] = diagonal
        ej = np.eye(1,p,j)[0]
        if (np.max(np.abs(a[j])) <= a[j,j]+1e-12 and
                np.max(np.abs(a@candidate-ej)) <= nu+1e-10):
            theta[j] = candidate
            continue
        rhs = np.r_[ej+nu,-ej+nu]
        fit = linprog(objective,A_ub=constraints,b_ub=rhs,
                      bounds=(0,None),method='highs',
                      options={'primal_feasibility_tolerance':1e-8,
                               'dual_feasibility_tolerance':1e-8})
        if not fit.success:
            raise RuntimeError(f'Dantzig infeasible/failed: {fit.message}')
        theta[j] = fit.x[:p]-fit.x[p:]
        lp_count += 1
        dual = fit.ineqlin.marginals
        max_gap = max(max_gap,abs(float(fit.fun-rhs@dual)))
        max_dual = max(max_dual,float(np.maximum(constraints.T@dual-objective,0).max()),
                       float(np.maximum(dual,0).max()))
    residual = float(np.max(np.abs(np.eye(p)-theta@a)))
    if residual > nu+5e-7:
        raise RuntimeError('Dantzig residual exceeds tolerance')
    return theta,dict(dantzig_residual=residual,dantzig_lp_count=lp_count,
                      dantzig_dual_gap=max_gap,dantzig_dual_violation=max_dual,
                      inverse_row_norm=float(np.abs(theta).sum(1).max()))

def attack(honest, count, family):
    if count == 0:
        return honest.copy()
    center = np.median(honest,axis=0)
    if family == 'sign':
        bad = -4*center
    elif family == 'mimic':
        spread = np.std(honest,axis=0,ddof=1)
        bad = np.clip(center-1.5*spread*np.sign(center),honest.min(0),honest.max(0))
    else:
        raise ValueError(family)
    return np.vstack([honest,np.tile(bad,(count,1))])

def aggregate(reports,threshold,trim=True):
    count = int(np.floor(GAMMA*len(reports))) if trim else 0
    ordered = np.sort(reports,axis=0)
    kept = ordered[count:len(reports)-count] if count else ordered
    return soft(kept.mean(0),threshold)

def metrics(beta,truth):
    delta = beta-truth
    selected = np.abs(beta)>1e-10
    support = truth!=0
    return dict(linf=float(np.abs(delta).max()),l2=float(np.linalg.norm(delta)),
                l1=float(np.abs(delta).sum()),false_positive=int(np.sum(selected & ~support)),
                false_negative=int(np.sum(~selected & support)),
                exact_support=int(np.array_equal(selected,support)))

def run(task):
    setting,rep,n,p,family,*extra = task
    h = extra[0] if extra else H
    threshold_coefficient = extra[1] if len(extra)>1 else .09
    seed = 202609220+10000*setting+rep
    rng = np.random.default_rng(seed)
    faults = 0 if family == 'none' else 2
    truth = np.zeros(p)
    truth[:2] = [1.,-.8]
    sites = []
    for k in range(M-faults):
        phase = k/(M-1)
        rho = .1+.25*phase
        scale = .8+.4*phase
        raw = rng.choice([-1.,1.],size=(n,p))
        x = raw.copy()
        x[:,::2] = (raw[:,::2]+rho*raw[:,1::2])/np.sqrt(1+rho*rho)
        x *= scale
        errors = -.3+.6*phase+(.35+.3*phase)*rng.logistic(size=n)
        sites.append((x,x@truth+errors))
    level = np.sqrt(np.log(2*p)/n)
    pilots,diags = [],[]
    for x,y in sites:
        beta,diag = pilot(x,y,.18*level,h=h)
        pilots.append(beta)
        diags.append(diag)
    transmitted = attack(np.array(pilots),faults,family)
    beta0 = soft(np.median(transmitted,axis=0),.12*level)
    common = dict(setting=setting,rep=rep,seed=seed,n=n,p=p,m=M,
                  faults=faults,attack=family,bandwidth=h,gamma=GAMMA,
                  threshold_coefficient=threshold_coefficient)
    rows = [{**common,'method':'Initializer','round':0,**metrics(beta0,truth)}]
    solver_rows=[]
    beta=beta0.copy()
    for t,nu in enumerate(NU):
        messages,raw_messages,scalar_messages = [],[],[]
        for k,(x,y) in enumerate(sites):
            _,g,a,be = profile(x,y,beta,h=h,hessian=True)
            theta,diagnostic = dantzig(a,nu)
            messages.append(beta-theta@g)
            raw_messages.append(beta-g)
            scalar_messages.append(beta-4*g)
            solver_rows.append({**common,'site':k,'round':t+1,'nu':nu,
                                'intercept_error':max(be,diags[k]['intercept_error']),
                                'pilot_kkt':diags[k]['pilot_kkt'],
                                'pilot_iterations':diags[k]['pilot_iterations'],**diagnostic})
        threshold = threshold_coefficient*(1+.5**(t+1))*level
        reports = attack(np.array(messages),faults,family)
        if t == 0:
            for name,candidate in [
                ('Dantzig-Mean',aggregate(reports,threshold,trim=False)),
                ('Unit-TM',aggregate(attack(np.array(raw_messages),faults,family),threshold)),
                ('Scalar4-TM',aggregate(attack(np.array(scalar_messages),faults,family),threshold))]:
                rows.append({**common,'method':name,'round':1,**metrics(candidate,truth)})
        beta=aggregate(reports,threshold)
        rows.append({**common,'method':'Dantzig-TM','round':t+1,**metrics(beta,truth)})
    return rows,solver_rows

def write_csv(path,rows):
    with path.open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--reps',type=int,default=30)
    ap.add_argument('--workers',type=int,default=6)
    ap.add_argument('--output',type=Path,default=Path('../results'))
    ap.add_argument('--smoke',action='store_true')
    args=ap.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    settings=[(n,p,f) for n,p in [(40,80),(60,120)] for f in ['none','sign','mimic']]
    tasks=[(i,r,n,p,f) for i,(n,p,f) in enumerate(settings) for r in range(args.reps)]
    if args.smoke:
        tasks=[(1,0,40,80,'sign')]
    start=time.time(); rows=[]; diagnostics=[]
    if args.workers == 1:
        iterator=map(run,tasks)
        for result in iterator:
            rows.extend(result[0]);diagnostics.extend(result[1])
            print(f'completed {len(rows)//6}/{len(tasks)}; elapsed {time.time()-start:.1f}s',flush=True)
    else:
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            futures=[pool.submit(run,t) for t in tasks]
            for num,future in enumerate(as_completed(futures),1):
                a,b=future.result();rows.extend(a);diagnostics.extend(b)
                if num%6==0 or num==len(tasks):
                    print(f'completed {num}/{len(tasks)}; elapsed {time.time()-start:.1f}s',flush=True)
    rows.sort(key=lambda r:(r['setting'],r['rep'],r['round'],r['method']))
    diagnostics.sort(key=lambda r:(r['setting'],r['rep'],r['round'],r['site']))
    write_csv(args.output/'highdim_replicates.csv',rows)
    write_csv(args.output/'highdim_solver_diagnostics.csv',diagnostics)
    metadata=dict(reps=args.reps,settings=settings,seeds='202609220+10000*setting+rep',
                  seconds=time.time()-start,completed_tasks=len(tasks),bandwidth=H,
                  quantiles=TAUS.tolist(),tolerances=NU,workers=args.workers,
                  penalty_coefficient=.18,initializer_threshold_coefficient=.12,
                  refinement_threshold='0.09*(1+0.5**(t+1))*sqrt(log(2*p)/n), t=0,1',
                  status='complete',note='Practical fixed tuning; unknown theorem constants are not calibrated.')
    (args.output/'highdim_metadata.json').write_text(json.dumps(metadata,indent=2),encoding='utf-8')
    print(json.dumps(metadata,indent=2),flush=True)

if __name__=='__main__':
    main()
