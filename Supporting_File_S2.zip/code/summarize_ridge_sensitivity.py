"""Verify the ridge grid and generate its Online Resource 1 table."""
from pathlib import Path
import argparse
import csv
import json
import numpy as np

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--results',type=Path,default=Path('../results'))
    ap.add_argument('--artifacts',type=Path,default=Path('../figures'))
    args=ap.parse_args()
    args.artifacts.mkdir(parents=True,exist_ok=True)
    rows=list(csv.DictReader((args.results/'ridge_sensitivity_replicates.csv').open()))
    summary=list(csv.DictReader((args.results/'ridge_sensitivity_summary.csv').open()))
    assert len(rows)==360 and len(summary)==12
    for s in summary:
        sub=[r for r in rows if r['setting']==s['setting'] and r['ridge']==s['ridge']]
        assert len(sub)==30
        assert np.isclose(np.mean([float(r['l2']) for r in sub]),float(s['l2_mean']))
        assert np.isclose(np.mean([float(r['exact_support']) for r in sub]),
                          float(s['exact_support_mean']))
    lookup={(int(r['setting']),float(r['ridge'])):r for r in summary}
    lines=[r'\begin{tabular}{llrrr}',r'\toprule',
           r'$H$ & Attack & $\kappa=0.04$ & $\kappa=0.08$ & $\kappa=0.16$ \\',
           r'\midrule']
    for setting,(h,attack) in enumerate([(0,'Sign'),(1,'Sign'),
                                         (0,'Mimic'),(1,'Mimic')]):
        cells=[str(h),attack]
        for ridge in [.04,.08,.16]:
            s=lookup[(setting,ridge)]
            cells.append(f"{float(s['l2_mean']):.3f} ({float(s['l2_se']):.3f})")
        lines.append(' & '.join(cells)+r' \\')
    lines.extend([r'\bottomrule',r'\end{tabular}'])
    (args.artifacts/'ridge_sensitivity_table.tex').write_text(
        '\n'.join(lines)+'\n',encoding='utf-8')
    audit=dict(datasets=len({(r['setting'],r['rep']) for r in rows}),
               records=len(rows),settings=4,ridges=3,reps_per_setting=30,
               all_exact_support=all(float(r['exact_support'])==1 for r in rows),
               total_caps=sum(int(r['cap_count']) for r in rows))
    (args.results/'ridge_sensitivity_audit.json').write_text(
        json.dumps(audit,indent=2))
    print(json.dumps(audit,indent=2))
    print('\n'.join(lines))

if __name__=='__main__':
    main()
