"""Exploratory bandwidth and threshold grid for the p>n Dantzig experiment.

The grid is motivated by the original experiment's false positives. It is
therefore exploratory and is not used to select an optimal method in the paper.
"""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
import argparse
import csv
import json
import time
import numpy as np
from run_highdim import run, write_csv

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--reps',type=int,default=30)
    ap.add_argument('--workers',type=int,default=6)
    ap.add_argument('--output',type=Path,default=Path('../results'))
    args=ap.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    settings=[(1,'sign'),(2,'mimic')]
    grid=[(setting,r,40,80,attack,h,threshold)
          for setting,attack in settings
          for h in [.25,.40,.60]
          for threshold in [.09,.18]
          for r in range(args.reps)]
    start=time.time()
    rows=[]
    if args.workers==1:
        iterator=map(run,grid)
        for i,(out,_) in enumerate(iterator,1):
            rows.extend(out)
            if i%10==0:
                print(f'completed {i}/{len(grid)}, {time.time()-start:.0f}s',flush=True)
    else:
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            future=[pool.submit(run,task) for task in grid]
            for i,job in enumerate(as_completed(future),1):
                out,_=job.result()
                rows.extend(out)
                if i%10==0 or i==len(grid):
                    print(f'completed {i}/{len(grid)}, {time.time()-start:.0f}s',flush=True)
    rows.sort(key=lambda x:(x['setting'],x['bandwidth'],x['threshold_coefficient'],
                            x['rep'],x['round'],x['method']))
    write_csv(args.output/'sensitivity_replicates.csv',rows)
    summary=[]
    for setting,attack in settings:
        for h in [.25,.40,.60]:
            for coefficient in [.09,.18]:
                subset=[r for r in rows if r['setting']==setting and
                        r['bandwidth']==h and r['threshold_coefficient']==coefficient
                        and r['method']=='Dantzig-TM' and r['round']==2]
                assert len(subset)==args.reps
                def mean_se(key):
                    x=np.array([r[key] for r in subset],dtype=float)
                    return float(x.mean()),float(x.std(ddof=1)/np.sqrt(len(x)))
                l2,se=mean_se('l2')
                fp,fpse=mean_se('false_positive')
                exact,exactse=mean_se('exact_support')
                summary.append(dict(setting=setting,attack=attack,n=40,p=80,
                                    h=h,threshold_coefficient=coefficient,
                                    reps=args.reps,l2_mean=l2,l2_se=se,
                                    fp_mean=fp,fp_se=fpse,
                                    exact_support_mean=exact,exact_support_se=exactse))
    with (args.output/'sensitivity_summary.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(summary[0]))
        w.writeheader()
        w.writerows(summary)
    metadata=dict(reps=args.reps,task_count=len(grid),seeds='original setting IDs 1/2: 202609220+10000*setting+rep',
                  bandwidths=[.25,.40,.60],threshold_coefficients=[.09,.18],
                  sample_size=40,p=80,attacks=['sign','mimic'],seconds=time.time()-start,
                  interpretation='exploratory sensitivity; larger threshold motivated by prior false positives')
    (args.output/'sensitivity_metadata.json').write_text(json.dumps(metadata,indent=2))
    print(json.dumps(summary,indent=2),flush=True)

if __name__=='__main__':
    main()
