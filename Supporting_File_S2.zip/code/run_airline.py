"""Airline-data reanalysis with Chen--Zhu-style Byzantine attack families.

The input is the public 2008 ASA Data Expo flight file.  The script retains
January--April, removes cancelled flights and missing arrival delays, applies a
fixed 70/30 split, standardizes from training data, and forms 82 balanced
worker blocks.  It does not redistribute the raw airline data.

The reported BIRDCAGE values in the manuscript are transcribed from Chen and
Zhu (2024, Table 11); this script computes HC-RCQR and local-median values.
Attacks are translated to the Newton-step messages sent by HC-RCQR.
"""

from __future__ import annotations

import argparse
import csv
import math
import os
from pathlib import Path

for _key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_key, "1")

import numpy as np
import pandas as pd

from hcrcqr import (
    coordinate_trimmed_mean,
    fit_profile_scqr,
    newton_message,
    soft_threshold,
)


M_WORKERS = 82
TAUS = tuple(np.round(np.arange(0.05, 1.0, 0.05), 2))
FEATURES = ("DepTime", "ActualElapsedTime", "ArrTime", "Distance", "DayOfWeek")
DATA_SEED = 20260924
ATTACKS = ("gaussian", "omniscient", "bitflip")
ALPHAS = (0.10, 0.20)


def prepare_data(path: Path):
    """Return standardized worker train/test shards and scale metadata."""
    columns = ["Month", "Cancelled", "ArrDelay", *FEATURES]
    data = pd.read_csv(path, usecols=columns, compression="infer")
    data = data.loc[
        (data["Month"] <= 4)
        & (data["Cancelled"] == 0)
        & data["ArrDelay"].notna()
    ].dropna(subset=["ArrDelay", *FEATURES])
    if len(data) != 2_319_121:
        raise ValueError(
            "Expected 2,319,121 January--April complete records after the stated "
            f"filters; found {len(data):,}. Check the source file and version."
        )

    X = data.loc[:, FEATURES].to_numpy(dtype=float)
    y = np.abs(data["ArrDelay"].to_numpy(dtype=float))
    split_rng = np.random.default_rng(DATA_SEED)
    order = split_rng.permutation(len(y))
    n_train = round(0.70 * len(y))
    train_idx, test_idx = order[:n_train], order[n_train:]
    x_mean = X[train_idx].mean(axis=0)
    x_scale = X[train_idx].std(axis=0, ddof=1)
    x_scale = np.maximum(x_scale, 1e-10)
    y_mean = float(y[train_idx].mean())
    y_scale = float(y[train_idx].std(ddof=1))
    if y_scale <= 0:
        raise ValueError("The training response has zero variance.")
    X = (X - x_mean[None, :]) / x_scale[None, :]
    y = (y - y_mean) / y_scale

    train_rng = np.random.default_rng(DATA_SEED + 1)
    test_rng = np.random.default_rng(DATA_SEED + 2)
    train_parts = np.array_split(train_rng.permutation(train_idx), M_WORKERS)
    test_parts = np.array_split(test_rng.permutation(test_idx), M_WORKERS)

    data_rng = np.random.default_rng(DATA_SEED + 3)
    train_sites = []
    for indices in train_parts:
        Xi = X[indices].copy()
        yi = y[indices].copy()
        # Chen and Zhu add 10% synthetic high-response outliers to every block.
        n_out = int(round(0.10 * len(indices)))
        X_out = data_rng.normal(0.0, 1.0, size=(n_out, X.shape[1]))
        y_out = np.full(n_out, (10_000.0 - y_mean) / y_scale)
        train_sites.append((np.vstack((Xi, X_out)), np.r_[yi, y_out]))
    test_sites = [(X[idx].copy(), y[idx].copy()) for idx in test_parts]
    return train_sites, test_sites, y_scale, n_train, len(test_idx)


def corrupt_updates(
    all_counterfactual_updates: np.ndarray,
    bad_indices: np.ndarray,
    attack: str,
    rng: np.random.Generator,
) -> np.ndarray:
    """Apply the three attack families to Newton-step messages.

    Gaussian replaces a step by N(0, 100 I); omniscient scales the worker's
    counterfactual step by -100; bit-flip reverses the first five coordinates.
    """
    p = all_counterfactual_updates.shape[1]
    if attack == "gaussian":
        return rng.normal(0.0, 10.0, size=(len(bad_indices), p))
    bad = all_counterfactual_updates[bad_indices].copy()
    if attack == "omniscient":
        return -100.0 * bad
    if attack == "bitflip":
        bad[:, : min(5, p)] *= -1.0
        return bad
    raise ValueError(f"Unknown attack: {attack}")


def predict_rmse(
    beta: np.ndarray,
    train_sites,
    test_sites,
    honest_indices: np.ndarray,
) -> float:
    squared_error = 0.0
    n_test = 0
    for k in honest_indices:
        Xtr, ytr = train_sites[int(k)]
        Xte, yte = test_sites[int(k)]
        intercept = float(np.quantile(ytr - Xtr @ beta, 0.50))
        residual = yte - (Xte @ beta + intercept)
        squared_error += float(residual @ residual)
        n_test += len(yte)
    return math.sqrt(squared_error / n_test)


def run_assignment(
    seed: int,
    alpha: float,
    attack: str,
    train_sites,
    test_sites,
    local_fits: np.ndarray,
) -> list[dict[str, float | int | str]]:
    rng = np.random.default_rng(seed)
    m, p = local_fits.shape
    n_bad = int(math.floor(alpha * m))
    bad_indices = np.sort(rng.choice(m, size=n_bad, replace=False))
    honest_indices = np.setdiff1d(np.arange(m), bad_indices, assume_unique=True)

    local_counterfactual = -local_fits
    initial_bad_updates = corrupt_updates(
        local_counterfactual, bad_indices, attack, rng
    )
    initial_bad_messages = -initial_bad_updates
    init_messages = np.vstack((local_fits[honest_indices], initial_bad_messages))
    threshold = 0.018 + 0.030 * alpha
    beta = soft_threshold(np.median(init_messages, axis=0), 1.5 * threshold)
    beta_median = beta.copy()

    trim = min(alpha + 0.05, 0.40)
    ridge = 0.055
    bandwidth = 0.18
    path = []
    for t in range(5):
        counterfactual = np.vstack(
            [
                beta - newton_message(X, y, beta, TAUS, bandwidth, ridge)
                for X, y in train_sites
            ]
        )
        bad_updates = corrupt_updates(counterfactual, bad_indices, attack, rng)
        honest_messages = beta - counterfactual[honest_indices]
        bad_messages = beta - bad_updates
        received = np.vstack((honest_messages, bad_messages))
        aggregate = coordinate_trimmed_mean(received, trim)
        beta = soft_threshold(aggregate, threshold * (1.0 + 0.5 ** (t + 1)))
        path.append(beta.copy())

    rows = []
    for name, estimate in (("Med-L", beta_median), ("HC-RCQR", beta)):
        rows.append(
            {
                "seed": seed,
                "alpha": alpha,
                "attack": attack,
                "method": name,
                "n_byzantine": n_bad,
                "rmse_sd": predict_rmse(
                    estimate, train_sites, test_sites, honest_indices
                ),
            }
        )
    return rows


def summarize(rows: list[dict]) -> list[dict[str, float | int | str]]:
    grouped: dict[tuple[float, str, str], list[dict]] = {}
    for row in rows:
        key = (float(row["alpha"]), str(row["attack"]), str(row["method"]))
        grouped.setdefault(key, []).append(row)
    summary = []
    for (alpha, attack, method), values in sorted(grouped.items()):
        scores = np.asarray([float(row["rmse_sd"]) for row in values])
        summary.append(
            {
                "alpha": alpha,
                "attack": attack,
                "method": method,
                "reps": len(scores),
                "rmse_sd_mean": float(scores.mean()),
                "rmse_sd_se": float(scores.std(ddof=1) / math.sqrt(len(scores)))
                if len(scores) > 1
                else 0.0,
            }
        )
    return summary


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--reps", type=int, default=5)
    parser.add_argument("--output", type=Path, default=Path("../results"))
    args = parser.parse_args()

    train_sites, test_sites, y_scale, n_train, n_test = prepare_data(args.data)
    p = train_sites[0][0].shape[1]
    n_median = float(np.median([len(y) for _, y in train_sites]))
    local_penalty = 0.20 * math.sqrt(math.log(p) / n_median)
    local_fits = np.vstack(
        [
            fit_profile_scqr(
                X,
                y,
                TAUS,
                bandwidth=0.18,
                penalty=local_penalty,
                max_iter=180,
            )
            for X, y in train_sites
        ]
    )
    print(
        f"data verified: n={n_train + n_test:,}, train={n_train:,}, "
        f"test={n_test:,}, workers={M_WORKERS}, p={p}, q={len(TAUS)}, "
        f"response SD={y_scale:.6g}",
        flush=True,
    )
    print("all local initial fits completed", flush=True)

    rows = []
    args.output.mkdir(parents=True, exist_ok=True)
    setting_id = 0
    for alpha in ALPHAS:
        for attack in ATTACKS:
            setting_id += 1
            for rep in range(args.reps):
                seed = DATA_SEED + 10_000 * setting_id + rep
                rows.extend(
                    run_assignment(
                        seed,
                        alpha,
                        attack,
                        train_sites,
                        test_sites,
                        local_fits,
                    )
                )
                write_csv(args.output / "airline_replicates.csv", rows)
                write_csv(args.output / "airline_summary.csv", summarize(rows))
                print(
                    f"completed alpha={alpha:.2f}, attack={attack}, "
                    f"rep={rep + 1}/{args.reps}",
                    flush=True,
                )
    write_csv(args.output / "airline_replicates.csv", rows)
    write_csv(args.output / "airline_summary.csv", summarize(rows))


if __name__ == "__main__":
    main()
