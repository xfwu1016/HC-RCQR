"""Create a LaTeX table and audit the exploratory sensitivity grid."""
from pathlib import Path
import argparse
import csv
import json
import numpy as np

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--results',type=Path,default=Path('../results'))
    ap.add_argument('--artifacts',type=Path,default=Path('../figures'))
    args=ap.parse_args()
    args.artifacts.mkdir(parents=True,exist_ok=True)
    rows=list(csv.DictReader((args.results/'sensitivity_replicates.csv').open()))
    summary=list(csv.DictReader((args.results/'sensitivity_summary.csv').open()))
    assert len(summary)==12
    for s in summary:
        sub=[r for r in rows if int(r['setting'])==int(s['setting'])
             and float(r['bandwidth'])==float(s['h'])
             and float(r['threshold_coefficient'])==float(s['threshold_coefficient'])
             and r['method']=='Dantzig-TM' and int(r['round'])==2]
        assert len(sub)==int(s['reps'])
        for field in ['l2','false_positive','exact_support']:
            assert np.isclose(np.mean([float(r[field]) for r in sub]),float(s[
                {'l2':'l2_mean','false_positive':'fp_mean',
                 'exact_support':'exact_support_mean'}[field]]))
    lines=[r'\begin{tabular}{llrrrr}',r'\toprule',
           r'Attack & $h$ & Threshold coefficient & $\ell_2$ error & FP & Exact support \\',
           r'\midrule']
    for attack in ['sign','mimic']:
        for s in sorted((r for r in summary if r['attack']==attack),
                        key=lambda r:(float(r['h']),float(r['threshold_coefficient']))):
            name={'sign':'Sign reversal','mimic':'Mimic'}[attack]
            cells=[name if float(s['h'])==.25 and float(s['threshold_coefficient'])==.09 else '',
                   f"{float(s['h']):.2f}",f"{float(s['threshold_coefficient']):.2f}",
                   f"{float(s['l2_mean']):.3f} ({float(s['l2_se']):.3f})",
                   f"{float(s['fp_mean']):.2f}",f"{float(s['exact_support_mean']):.2f}"]
            lines.append(' & '.join(cells)+r' \\')
        if attack=='sign':
            lines.append(r'\addlinespace[2pt]')
    lines.extend([r'\bottomrule',r'\end{tabular}'])
    (args.artifacts/'sensitivity_table.tex').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    audit=dict(tasks=len({(r['setting'],r['bandwidth'],r['threshold_coefficient'],r['rep']) for r in rows}),
               records=len(rows),summary_rows=len(summary),
               min_reps=min(int(r['reps']) for r in summary),
               max_reps=max(int(r['reps']) for r in summary),
               unique_seeds=len({r['seed'] for r in rows}))
    (args.results/'sensitivity_audit.json').write_text(json.dumps(audit,indent=2))
    print(json.dumps(audit,indent=2))
    print('\n'.join(lines))

if __name__=='__main__':
    main()
