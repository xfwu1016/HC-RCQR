"""Algebra and solver tests for the high-dimensional experiment."""
import unittest
import numpy as np
from scipy.optimize import linprog
from run_highdim import profile,dantzig,pilot,aggregate,soft

class HighDimensionalChecks(unittest.TestCase):
    def setUp(self):
        self.rng=np.random.default_rng(74831)

    def test_profile_rank_and_derivative(self):
        x=self.rng.choice([-1.,1.],size=(24,32))
        beta=np.zeros(32); beta[:2]=[.7,-.6]
        y=x@beta+self.rng.logistic(size=24)
        _,g,a,res=profile(x,y,beta,hessian=True)
        self.assertLess(res,1e-9)
        self.assertEqual(np.linalg.matrix_rank(a,tol=1e-8),23)
        direction=np.zeros(32);direction[:3]=[1.,-.5,.2]
        eps=1e-5
        gp=profile(x,y,beta+eps*direction)[1]
        gm=profile(x,y,beta-eps*direction)[1]
        np.testing.assert_allclose((gp-gm)/(2*eps),a@direction,atol=1e-8)

    def test_exact_diagonal_shortcut_against_lp(self):
        a=np.eye(8)+.02*np.ones((8,8))
        theta,diag=dantzig(a,.4)
        self.assertEqual(diag['dantzig_lp_count'],0)
        mat=np.hstack([a,-a])
        for j in range(8):
            ej=np.eye(8)[j]
            fit=linprog(np.ones(16),A_ub=np.vstack([mat,-mat]),
                        b_ub=np.r_[ej+.4,-ej+.4],bounds=(0,None),method='highs')
            self.assertTrue(fit.success)
            self.assertAlmostEqual(np.abs(theta[j]).sum(),fit.fun,places=8)

    def test_full_lp_and_pilot(self):
        x=self.rng.choice([-1.,1.],size=(24,32))
        beta=np.zeros(32);beta[:2]=[.9,-.7]
        y=x@beta+.4*self.rng.logistic(size=24)
        fit,diag=pilot(x,y,.08)
        self.assertLessEqual(diag['pilot_kkt'],2e-7)
        a=profile(x,y,fit,hessian=True)[2]
        theta,diag=dantzig(a,.3)
        self.assertLessEqual(np.abs(np.eye(32)-theta@a).max(),.3+5e-7)
        self.assertGreater(diag['dantzig_lp_count'],0)

    def test_trim_perturbation_and_threshold(self):
        x=self.rng.normal(size=(8,12))
        perturb=self.rng.uniform(-.01,.01,size=x.shape)
        self.assertLessEqual(np.max(np.abs(aggregate(x,.1)-aggregate(x+perturb,.1))),.01+1e-12)
        truth=np.r_[1.,-.8,np.zeros(10)]
        v=truth+self.rng.uniform(-.05,.05,12)
        estimate=soft(v,.05)
        self.assertTrue(np.all(estimate[2:]==0))
        self.assertLessEqual(np.max(np.abs(estimate-truth)),.1)

if __name__=='__main__':
    unittest.main(verbosity=2)
