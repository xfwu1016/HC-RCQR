"""Exploratory ridge-tuning grid on the archived paired CQR designs."""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[key]='1'
import argparse
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import json
import numpy as np
from hcrcqr import (fit_profile_scqr,profile_components,attack_messages,
                    soft_threshold,coordinate_trimmed_mean)
from run_simulation import generate_sites,write_csv

RIDGES=(.04,.08,.16)
SETTINGS=((0.,'sign'),(1.,'sign'),(0.,'mimic'),(1.,'mimic'))

def run(job):
    setting,rep=job
    heterogeneity,attack=SETTINGS[setting]
    seed=202609150+setting*1000+rep
    m,n,p=20,90,30
    truth=np.zeros(p)
    truth[:5]=[1.,-.82,.66,-.46,.24]
    sites=generate_sites(np.random.default_rng(seed),m,n,p,truth,heterogeneity)[:16]
    taus=(.25,.5,.75)
    h=.24
    floor=.042
    penalty=.24*np.sqrt(np.log(p)/n)
    local=np.vstack([fit_profile_scqr(x,y,taus,h,penalty,max_iter=180)
                     for x,y in sites])
    bad=attack_messages(local,4,attack,np.random.default_rng(seed+100000))
    initial=soft_threshold(np.median(np.vstack([local,bad]),axis=0),1.5*floor)
    output=[]
    for ridge in RIDGES:
        beta=initial.copy()
        total_caps=0
        for t in range(4):
            messages=[]
            for x,y in sites:
                _,g,a,_=profile_components(x,y,beta,taus,h)
                step=np.linalg.solve(a+ridge*np.eye(p),g)
                radius=2.5*max(1.,np.linalg.norm(beta))
                norm=np.linalg.norm(step)
                if norm>radius:
                    step*=radius/norm
                    total_caps+=1
                messages.append(beta-step)
            bad=attack_messages(np.vstack(messages),4,attack,
                                np.random.default_rng(seed+200000+t))
            beta=soft_threshold(
                coordinate_trimmed_mean(np.vstack([messages,bad]),.25),
                floor*(1+.5**(t+1)))
        support=np.abs(beta)>.08
        truth_support=np.abs(truth)>.08
        output.append(dict(setting=setting,rep=rep,seed=seed,
                           heterogeneity=heterogeneity,attack=attack,
                           ridge=ridge,rounds=4,l2=float(np.linalg.norm(beta-truth)),
                           false_positive=int(np.sum(support & ~truth_support)),
                           false_negative=int(np.sum(~support & truth_support)),
                           exact_support=int(np.array_equal(support,truth_support)),
                           cap_count=total_caps))
    return output

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--reps',type=int,default=30)
    ap.add_argument('--workers',type=int,default=6)
    ap.add_argument('--output',type=Path,default=Path('../results'))
    args=ap.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    jobs=[(j,r) for j in range(len(SETTINGS)) for r in range(args.reps)]
    rows=[]
    if args.workers==1:
        for i,job in enumerate(jobs,1):
            rows.extend(run(job))
            if i%10==0:
                print(f'completed {i}/{len(jobs)}',flush=True)
    else:
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            for i,result in enumerate(pool.map(run,jobs),1):
                rows.extend(result)
                if i%10==0:
                    print(f'completed {i}/{len(jobs)}',flush=True)
    rows.sort(key=lambda r:(r['setting'],r['rep'],r['ridge']))
    write_csv(args.output/'ridge_sensitivity_replicates.csv',rows)
    summary=[]
    for setting,(heterogeneity,attack) in enumerate(SETTINGS):
        for ridge in RIDGES:
            sub=[r for r in rows if r['setting']==setting and r['ridge']==ridge]
            assert len(sub)==args.reps
            x=np.array([r['l2'] for r in sub])
            summary.append(dict(setting=setting,heterogeneity=heterogeneity,
                                attack=attack,ridge=ridge,reps=args.reps,
                                l2_mean=float(x.mean()),
                                l2_se=float(x.std(ddof=1)/np.sqrt(len(x))),
                                exact_support_mean=float(np.mean([r['exact_support'] for r in sub])),
                                cap_count_mean=float(np.mean([r['cap_count'] for r in sub]))))
    write_csv(args.output/'ridge_sensitivity_summary.csv',summary)
    metadata=dict(settings=SETTINGS,ridges=RIDGES,reps=args.reps,
                  seed='202609150+1000*setting+rep',status='complete',
                  interpretation='exploratory sensitivity with original matched datasets and algorithm budgets')
    (args.output/'ridge_sensitivity_metadata.json').write_text(json.dumps(metadata,indent=2))
    print(json.dumps(summary,indent=2),flush=True)

if __name__=='__main__':
    main()
