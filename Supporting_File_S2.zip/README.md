# Supporting File S2: reproducibility archive

Article: *Heterogeneity-calibrated Byzantine-robust distributed composite
quantile regression*

Authors: Xiaofei Wu; Jian Qing Shi

Corresponding author: Jian Qing Shi  
Corresponding affiliation: Department of Statistics and Data Science, Beijing
Normal--Hong Kong Baptist University, Zhuhai, China  
Corresponding e-mail: jianqingshi@bnbu.edu.cn

## Contents

- **code/hcrcqr.py**: estimator, attacks, baselines, and evaluation functions.
- **code/run_simulation.py**: all six reported Monte Carlo settings.
- **code/run_bikesharing.py**: the temporally split UCI Bike Sharing analysis.
- **code/run_airline.py**: the airline-delay application and HC-RCQR/Med-L
  reanalysis on the public 2008 ASA Data Expo flight data.
- **code/make_artifacts.py**: regeneration of table fragments and figure data.
- **code/test_hcrcqr.py**: deterministic implementation checks.
- **code/run_highdim.py**: uncapped Dantzig experiments, 30 replications per setting.
- **code/summarize_highdim.py**: high-dimensional tables, paired comparisons and vector plot source.
- **code/test_highdim.py**: profiling, Dantzig and numerical-derivative checks.
- **code/run_sensitivity.py**: exploratory bandwidth and threshold grid using
  the same high-dimensional Dantzig implementation.
- **code/summarize_sensitivity.py**: sensitivity audit and Appendix S1 table.
- **code/run_ridge_sensitivity.py**: exploratory ridge grid on the original
  paired moderate-dimensional designs.
- **code/summarize_ridge_sensitivity.py**: ridge-grid audit and table.
- **code/run_matched.py**: added paired calibration comparison (50 replications
  per setting); changes only the preconditioner, using common initialization,
  four rounds, thresholds, attack seeds and norm caps.
- **results/**: replicate-level and summarized results used in the manuscript.
- **figures/**: values used to draw the simulation error and support-recovery plots and the Bike Sharing performance plot.
- **data/README.md**: public-data retrieval and integrity instructions.
- **results/airline_replicates.csv** and **results/airline_summary.csv**:
  replicate-level and summarized airline results.

## Software environment

The moderate-dimensional studies and applications use capped ridge updates.
The high-dimensional study uses uncapped Dantzig updates with fixed practical
tuning under the independent-error model.
Probability bounds and proofs are provided in Appendix S1.

The archived results were generated with:

- Python 3.12.14
- NumPy 2.3.5
- pandas 3.0.1
- SciPy 1.18.1 (high-dimensional experiment)

Install the recorded dependencies with:

    python -m pip install -r requirements.txt

## Reproduce the checks and simulations

Run these commands from the **code** directory:

    python -m unittest -v test_hcrcqr.py
    python run_simulation.py --reps 50 --output ../results
    python run_bikesharing.py --data ../data/hour.csv --reps 10 --output ../results
    python run_airline.py --data ../data/2008.csv.bz2 --reps 5 --output ../results
    python make_artifacts.py
    python run_matched.py --reps 50 --workers 4
    python run_highdim.py --reps 30 --workers 6 --output ../results
    python summarize_highdim.py --results ../results --artifacts ../figures
    python -m unittest -v test_highdim.py
    python run_sensitivity.py --reps 30 --workers 6 --output ../results
    python summarize_sensitivity.py --results ../results --artifacts ../figures
    python run_ridge_sensitivity.py --reps 30 --workers 6 --output ../results
    python summarize_ridge_sensitivity.py --results ../results --artifacts ../figures

Compile figures/highdim_figure.tex with pdfLaTeX to regenerate the new
vector figure. The high-dimensional archive contains 180 independent runs,
1,080 method/round records and 2,400 solver records. No replicate was excluded.
Compare methods at round 1; only Dantzig--TM continues to round 2.
Support uses a numerical zero cutoff of 1e-10. The practical thresholds
produce false positives after refinement. The scalar 4I preconditioner has
smaller one-round error in five of the six settings.

The sensitivity grid uses the original sign-reversal and mimic settings at
(n,p)=(40,80), with the same 30 seeds per setting. Bandwidths are
0.25, 0.40, 0.60 and refinement threshold coefficients are 0.09 and 0.18.
The larger threshold was selected for this exploratory follow-up after the
original experiment showed false positives. It was not prespecified for
the original six-setting comparison, and the grid is not used to choose
the main experiment's tuning.

The ridge sensitivity uses the first 30 seeds from each setting in the
original matched experiment and varies only the ridge constant
across 0.04, 0.08, and 0.16. The grid was run as an exploratory
follow-up and is not used to retune the main estimates.

The Monte Carlo driver uses 50 independent seeds for each of six settings.
The Bike Sharing driver uses ten independently seeded Byzantine-site
assignments for each attacked setting. Seeds and all method-level outcomes are
stored in the replicate files.

The no-attack Bike Sharing analysis is deterministic, so reported Monte Carlo
standard errors round to zero.

The airline analysis follows the reported January--April 2008 sample size,
70/30 split, 82 worker blocks, and 10% synthetic high-response outliers per
training block in Chen and Zhu (2024, Section 4.7). It uses five numeric
covariates and 19 quantile levels from 0.05 to 0.95 in increments of 0.05.
Attack families operate on HC-RCQR's Newton-step messages. In this application,
Med-L denotes the median-and-soft-thresholded local initializer used by HC-RCQR.
The published BIRDCAGE values are taken from Table 11 of Chen and Zhu (2024).
They provide an external reference with different features, attack implementations,
and evaluation subsets. For each attack and
Byzantine fraction, the airline script uses five attack-site assignments and
messages under a fixed train/test split. It evaluates response-standardized
test RMSE on honest sites and stores all seed-level values, means, and standard
errors. The raw flight file is not redistributed.

## Data and redistribution

The UCI source data are not redistributed in this archive. Download
**Bike-Sharing-Dataset.zip** from the permanent repository record
<https://doi.org/10.24432/C5W894>, extract **hour.csv**, and place it at
**data/hour.csv**. See **data/README.md** for the source citation and validation
checks.

The airline source data are also not redistributed. Download the 2008 flight
file from the ASA Data Expo 2009 record at
<https://doi.org/10.7910/DVN/HG7NV7> (a mirror is listed in
**data/README.md**) and pass the compressed CSV to `run_airline.py`.

## Scope

The moderate-dimensional experiments use a ridge inverse profile Hessian.
The added high-dimensional experiments solve rowwise Dantzig programs,
without symmetrization, using SciPy's HiGHS solver and a verified exact
diagonal shortcut when applicable.

The Bike Sharing penalty uses the median training size over all participating
sites, so tuning does not use Byzantine-worker identities. Continuous-feature standardization is computed
from pooled training data and treated as trusted preprocessing; attacks affect
only model messages. The Newton implementation also caps large steps for
numerical stability, whereas the stated theory concerns uncapped messages.
The original method comparisons use their archived method-specific initializations
and iteration budgets. The added matched comparison is reported separately in
`matched_replicates.csv` and `matched_summary.csv`. It compares a local ridge
inverse with scalar preconditioners 1, 4 and 8, without post-hoc step selection.
Round-level records include honest-message dispersion and cap counts. Paired
differences are scalar error minus local-inverse error. Scalar step 4 has
slightly lower mean error under heterogeneous sign reversal; all results are retained.

Each experiment's numerical records correspond to its documented tuning.

The sign-reversal and mimic attacks are constructed from the realized honest
messages at each attack step and are therefore omniscient stress tests.
