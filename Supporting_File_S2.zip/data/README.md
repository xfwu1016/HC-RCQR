# UCI Bike Sharing data

The empirical study uses the hourly data from:

Hadi Fanaee-T (2013), *Bike Sharing*, UCI Machine Learning Repository,
<https://doi.org/10.24432/C5W894>.

Download the repository ZIP, extract **hour.csv**, and place that file in this
directory. The analysis expects:

- 17,379 data rows, excluding the header (the actual number in hour.csv);
- the columns documented by UCI, including instant, yr, mnth, hr, temp, atemp,
  hum, windspeed, casual, registered, and cnt;
- no missing values.

For the exact file used in this study, the SHA-256 checksum is
`e03de4ee4ef4dc376ac6e04bf829673c6269e8eba5c60fa121640fa2f829504f`.
The split contains 13,895 training records and 3,484 test records across
24 monthly sites, with 38 encoded predictors.

The script excludes casual and registered because their sum equals the
response cnt; this prevents target leakage. It also performs every
continuous-variable transformation using training records only.

# Airline on-time performance data

The airline application uses the 2008 file from the ASA Data Expo 2009
collection, available from Harvard Dataverse at
<https://doi.org/10.7910/DVN/HG7NV7>. A convenient mirror of the same annual
CSV is listed at <https://www.stat.ucdavis.edu/~duncan/Data/rdatasciencecases/Airline/>.
Place the compressed file `2008.csv.bz2` in this directory or pass its path
to `code/run_airline.py`. The downloaded UC Davis mirror file has SHA-256
`cc1fab9ada5ae6a879c00fa102340d0359d1ff25c9630895c054fe69c2aa9f92`.

The script keeps January--April flights, removes cancellations and records
with missing arrival delay or selected predictors, and checks that the result
contains 2,319,121 observations. The response is the absolute arrival delay
in minutes. Predictors are departure time, actual elapsed time, arrival time,
distance, and day of week. A fixed seed determines the 70/30 training/test
split; training data are divided into 82 balanced worker blocks. Features and
response are standardized using training data only. Each training block then
receives 10% synthetic outliers with standardized covariates drawn from
$N(0,I)$ and response set to 10,000 minutes before standardization. No raw
airline records are included in the archive.
